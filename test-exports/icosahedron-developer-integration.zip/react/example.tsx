import TriQRModel from "./TriQRModel";

export default function IdentitySection() {
  return (
    <section style={{ maxWidth: 800, margin: "40px auto", padding: 20 }}>
      <h2 style={{ fontSize: 28, color: "#2B2118" }}>My Digital Identity</h2>
      <p style={{ color: "#82776D" }}>
        Interactive 3D model. Click any face to bring it forward for easy scanning.
      </p>

      <div style={{ marginTop: 24, borderRadius: 16, overflow: "hidden", border: "1px solid #EAE2D9" }}>
        <TriQRModel
          src="/models/icosahedron.glb"
          height={520}
          background="#F5F0E9"
        />
      </div>
    </section>
  );
}
