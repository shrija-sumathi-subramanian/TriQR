/**
 * TriQR Web Component — <triqr-model>
 * A standalone, reusable 3D identity viewer with drag, zoom, and upright click-to-front.
 *
 * Usage:
 *   <triqr-model src="/models/my-triqr.glb" height="520px"></triqr-model>
 *   <script type="module" src="/triqr/triqr-embed.js"></script>
 */

import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.187.0/build/three.module.js';
import { GLTFLoader } from 'https://cdn.jsdelivr.net/npm/three@0.187.0/examples/jsm/loaders/GLTFLoader.js';
import { OrbitControls } from 'https://cdn.jsdelivr.net/npm/three@0.187.0/examples/jsm/controls/OrbitControls.js';

class TriQRModel extends HTMLElement {
  static get observedAttributes() {
    return ['src', 'height', 'width', 'background'];
  }

  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this._animId = 0;
    this._turnFrame = 0;
    this._turning = false;
    this._model = null;
    this._controls = null;
    this._renderer = null;
    this._scene = null;
    this._camera = null;
    this._resizeObserver = null;
  }

  connectedCallback() {
    this._setupDOM();
    this._initThree();
    this._loadModel();
  }

  disconnectedCallback() {
    this._cleanup();
  }

  attributeChangedCallback(name, oldVal, newVal) {
    if (oldVal === newVal) return;
    if (name === 'src' && this._renderer) {
      this._loadModel();
    } else if (name === 'background' && this._scene) {
      this._scene.background = new THREE.Color(newVal || '#F5F0E9');
    }
  }

  _setupDOM() {
    const height = this.getAttribute('height') || '480px';
    const width = this.getAttribute('width') || '100%';
    const bg = this.getAttribute('background') || '#F5F0E9';

    this.shadowRoot.innerHTML = [
      '<style>',
      ':host { display: block; position: relative; width: ' + width + '; height: ' + height + '; min-height: 280px; background: ' + bg + '; border-radius: 12px; overflow: hidden; }',
      'canvas { display: block; width: 100%; height: 100%; touch-action: none; }',
      '.status-overlay { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); font-family: system-ui, -apple-system, sans-serif; font-size: 14px; color: #82776D; pointer-events: none; }',
      '</style>',
      '<div class="status-overlay" id="status">Loading 3D model…</div>',
      '<canvas id="canvas"></canvas>'
    ].join('\n');
  }

  _initThree() {
    const canvas = this.shadowRoot.querySelector('#canvas');
    const bg = this.getAttribute('background') || '#F5F0E9';

    this._renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false });
    this._renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this._renderer.outputColorSpace = THREE.SRGBColorSpace;
    this._renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this._renderer.toneMappingExposure = 1.0;

    this._scene = new THREE.Scene();
    this._scene.background = new THREE.Color(bg);

    this._camera = new THREE.PerspectiveCamera(38, 1, 0.05, 1000);

    this._scene.add(new THREE.HemisphereLight(0xffffff, 0xd0c4b8, 0.95));
    const dirLight1 = new THREE.DirectionalLight(0xffffff, 1.0);
    dirLight1.position.set(4, 6, 5);
    this._scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0xffffff, 0.35);
    dirLight2.position.set(-4, 2, -3);
    this._scene.add(dirLight2);

    this._controls = new OrbitControls(this._camera, canvas);
    this._controls.enableDamping = true;
    this._controls.dampingFactor = 0.08;
    this._controls.enablePan = false;
    this._controls.rotateSpeed = 0.8;
    this._controls.zoomSpeed = 0.8;

    this._setupEvents(canvas);

    this._resizeObserver = new ResizeObserver(() => this._onResize());
    this._resizeObserver.observe(canvas);
    this._onResize();

    const render = () => {
      this._animId = requestAnimationFrame(render);
      if (!this._turning && this._controls) this._controls.update();
      if (this._renderer && this._scene && this._camera) {
        this._renderer.render(this._scene, this._camera);
      }
    };
    render();
  }

  _onResize() {
    if (!this._renderer || !this._camera) return;
    const canvas = this.shadowRoot.querySelector('#canvas');
    if (!canvas) return;
    const w = Math.max(1, canvas.clientWidth);
    const h = Math.max(1, canvas.clientHeight);
    this._renderer.setSize(w, h, false);
    this._camera.aspect = w / h;
    this._camera.updateProjectionMatrix();
  }

  _loadModel() {
    const src = this.getAttribute('src');
    const statusEl = this.shadowRoot.querySelector('#status');
    if (!src) {
      if (statusEl) statusEl.textContent = 'No model source specified';
      return;
    }

    if (this._model) {
      this._scene.remove(this._model);
      this._model = null;
    }

    if (statusEl) {
      statusEl.style.display = 'block';
      statusEl.textContent = 'Loading 3D model…';
    }

    const loader = new GLTFLoader();
    loader.load(
      src,
      (gltf) => {
        this._model = gltf.scene;
        this._scene.add(this._model);
        this._model.updateMatrixWorld(true);

        const box = new THREE.Box3().setFromObject(this._model);
        const center = box.getCenter(new THREE.Vector3());
        this._model.position.sub(center);
        this._model.updateMatrixWorld(true);

        const size = box.getSize(new THREE.Vector3()).length() || 3;
        this._camera.position.set(0, 0, size * 1.55);
        this._camera.near = Math.max(size / 500, 0.01);
        this._camera.far = size * 100;
        this._camera.updateProjectionMatrix();

        this._controls.target.set(0, 0, 0);
        this._controls.minDistance = size * 0.7;
        this._controls.maxDistance = size * 5.0;
        this._controls.update();

        if (statusEl) statusEl.style.display = 'none';
        this.dispatchEvent(new CustomEvent('load', { detail: { model: this._model } }));
      },
      undefined,
      (error) => {
        console.error('TriQR Model load error:', error);
        if (statusEl) statusEl.textContent = 'Failed to load 3D model';
        this.dispatchEvent(new CustomEvent('error', { detail: { error } }));
      }
    );
  }

  _setupEvents(canvas) {
    let downX = 0, downY = 0, isDragging = false;
    const raycaster = new THREE.Raycaster();
    const pointer = new THREE.Vector2();

    canvas.addEventListener('pointerdown', (e) => {
      downX = e.clientX;
      downY = e.clientY;
      isDragging = false;
    });

    canvas.addEventListener('pointermove', (e) => {
      if (Math.hypot(e.clientX - downX, e.clientY - downY) > 5) {
        isDragging = true;
      }
    });

    canvas.addEventListener('click', (e) => {
      if (!this._model || isDragging || this._turning) return;

      const rect = canvas.getBoundingClientRect();
      pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(pointer, this._camera);

      const hits = raycaster.intersectObjects(this._model.children, true);
      if (!hits.length) return;

      let faceNode = null;
      for (const hit of hits) {
        let curr = hit.object;
        while (curr && curr !== this._model) {
          if (curr.userData && curr.userData.triqrFaceId) {
            faceNode = curr;
            break;
          }
          if (curr.name && curr.name.startsWith('TriQR_Face_')) {
            faceNode = curr;
            break;
          }
          curr = curr.parent;
        }
        if (faceNode) break;
      }

      let faceRotation = null;
      if (faceNode && faceNode.userData && Array.isArray(faceNode.userData.triqrRotation)) {
        faceRotation = new THREE.Quaternion(...faceNode.userData.triqrRotation);
      } else if (faceNode) {
        faceRotation = faceNode.quaternion.clone();
      } else {
        const hit = hits.find(h => h.object.name && !h.object.name.includes('Body') && h.face);
        if (hit && hit.face) {
          const worldNormal = hit.face.normal.clone().transformDirection(hit.object.matrixWorld).normalize();
          const localNormal = worldNormal.clone().applyQuaternion(this._model.quaternion.clone().invert()).normalize();
          const up = new THREE.Vector3(0, 1, 0);
          let pUp = up.clone().addScaledVector(localNormal, -up.dot(localNormal)).normalize();
          if (pUp.lengthSq() < 0.001) pUp.set(0, 0, 1);
          const right = pUp.clone().cross(localNormal).normalize();
          const cUp = localNormal.clone().cross(right).normalize();
          faceRotation = new THREE.Quaternion().setFromRotationMatrix(
            new THREE.Matrix4().makeBasis(right, cUp, localNormal)
          );
        }
      }

      if (!faceRotation) return;

      // Upright orientation formula
      const cameraPos = new THREE.Vector3();
      const modelPos = new THREE.Vector3();
      this._camera.getWorldPosition(cameraPos);
      this._model.getWorldPosition(modelPos);

      const faceNormalWorld = cameraPos.clone().sub(modelPos).normalize();
      const worldUp = new THREE.Vector3(0, 1, 0);
      let projectedUp = worldUp.clone().addScaledVector(faceNormalWorld, -worldUp.dot(faceNormalWorld));
      if (projectedUp.lengthSq() < 0.001) {
        projectedUp.set(0, 0, 1).addScaledVector(faceNormalWorld, -faceNormalWorld.z);
      }
      projectedUp.normalize();

      const right = projectedUp.clone().cross(faceNormalWorld).normalize();
      const correctedUp = faceNormalWorld.clone().cross(right).normalize();

      const faceMatrix = new THREE.Matrix4().makeBasis(right, correctedUp, faceNormalWorld);
      const desiredFaceWorld = new THREE.Quaternion().setFromRotationMatrix(faceMatrix);
      const desiredRootWorld = desiredFaceWorld.clone().multiply(faceRotation.clone().invert());

      if (this._model.parent) {
        const parentWorldRot = new THREE.Quaternion();
        this._model.parent.getWorldQuaternion(parentWorldRot);
        desiredRootWorld.premultiply(parentWorldRot.invert());
      }

      const startQuat = this._model.quaternion.clone();
      const targetQuat = desiredRootWorld;

      this._turning = true;
      this._controls.enabled = false;
      const startTime = performance.now();
      const duration = 600;

      const animateStep = (now) => {
        const elapsed = now - startTime;
        const progress = Math.min(1, elapsed / duration);
        const ease = 1 - Math.pow(1 - progress, 3);

        this._model.quaternion.slerpQuaternions(startQuat, targetQuat, ease);

        if (progress < 1) {
          this._turnFrame = requestAnimationFrame(animateStep);
        } else {
          this._model.quaternion.copy(targetQuat);
          this._turning = false;
          this._controls.enabled = true;
        }
      };

      cancelAnimationFrame(this._turnFrame);
      this._turnFrame = requestAnimationFrame(animateStep);
    });
  }

  _cleanup() {
    cancelAnimationFrame(this._animId);
    cancelAnimationFrame(this._turnFrame);
    if (this._resizeObserver) this._resizeObserver.disconnect();
    if (this._controls) this._controls.dispose();
    if (this._renderer) {
      this._renderer.dispose();
      this._renderer.forceContextLoss();
    }
  }
}

if (!customElements.get('triqr-model')) {
  customElements.define('triqr-model', TriQRModel);
}
export { TriQRModel };
