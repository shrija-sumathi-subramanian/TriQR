"use client";

import { useEffect, useRef, useState } from "react";
import type { CSSProperties } from "react";
import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";

export type TriQRModelProps = {
  src: string;
  height?: number | string;
  width?: number | string;
  background?: string;
  className?: string;
  style?: CSSProperties;
  onLoad?: () => void;
  onError?: (error: Error) => void;
};

export default function TriQRModel({
  src,
  height = 520,
  width = "100%",
  background = "#F5F0E9",
  className,
  style,
  onLoad,
  onError,
}: TriQRModelProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    let animId = 0;
    let turnFrame = 0;
    let turning = false;
    let model: THREE.Group | null = null;

    const canvas = document.createElement("canvas");
    canvas.style.display = "block";
    canvas.style.width = "100%";
    canvas.style.height = "100%";
    canvas.style.touchAction = "none";
    container.appendChild(canvas);

    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.0;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(background);

    const camera = new THREE.PerspectiveCamera(38, 1, 0.05, 1000);

    scene.add(new THREE.HemisphereLight(0xffffff, 0xd0c4b8, 1.4));
    const dirLight1 = new THREE.DirectionalLight(0xffffff, 1.6);
    dirLight1.position.set(4, 6, 5);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0xffffff, 0.7);
    dirLight2.position.set(-4, -2, -3);
    scene.add(dirLight2);

    const controls = new OrbitControls(camera, canvas);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.enablePan = false;
    controls.rotateSpeed = 0.8;
    controls.zoomSpeed = 0.8;

    function handleResize() {
      const w = Math.max(1, container?.clientWidth || 300);
      const h = Math.max(1, container?.clientHeight || 300);
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    }

    const resizeObserver = new ResizeObserver(handleResize);
    resizeObserver.observe(container);
    handleResize();

    setLoading(true);
    setErrorMessage(null);

    const loader = new GLTFLoader();
    loader.load(
      src,
      (gltf) => {
        model = gltf.scene;
        scene.add(model);
        model.updateMatrixWorld(true);

        const box = new THREE.Box3().setFromObject(model);
        const center = box.getCenter(new THREE.Vector3());
        model.position.sub(center);
        model.updateMatrixWorld(true);

        const size = box.getSize(new THREE.Vector3()).length() || 3;
        camera.position.set(0, 0, size * 1.55);
        camera.near = Math.max(size / 500, 0.01);
        camera.far = size * 100;
        camera.updateProjectionMatrix();

        controls.target.set(0, 0, 0);
        controls.minDistance = size * 0.7;
        controls.maxDistance = size * 5.0;
        controls.update();

        setLoading(false);
        onLoad?.();
      },
      undefined,
      (err) => {
        const error = err instanceof Error ? err : new Error("Failed to load 3D model");
        console.error("TriQRModel loading error:", error);
        setLoading(false);
        setErrorMessage("Failed to load 3D model");
        onError?.(error);
      }
    );

    // Pointer events for upright click-to-front
    let downX = 0, downY = 0, isDragging = false;
    const raycaster = new THREE.Raycaster();
    const pointer = new THREE.Vector2();

    const onPointerDown = (e: PointerEvent) => {
      downX = e.clientX;
      downY = e.clientY;
      isDragging = false;
    };

    const onPointerMove = (e: PointerEvent) => {
      if (Math.hypot(e.clientX - downX, e.clientY - downY) > 5) {
        isDragging = true;
      }
    };

    const onClick = (e: MouseEvent) => {
      if (!model || isDragging || turning) return;

      const rect = canvas.getBoundingClientRect();
      pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(pointer, camera);

      const hits = raycaster.intersectObjects(model.children, true);
      if (!hits.length) return;

      let faceNode: THREE.Object3D | null = null;
      for (const hit of hits) {
        let curr: THREE.Object3D | null = hit.object;
        while (curr && curr !== model) {
          if (curr.userData && curr.userData.triqrFaceId) {
            faceNode = curr;
            break;
          }
          if (curr.name && curr.name.startsWith("TriQR_Face_")) {
            faceNode = curr;
            break;
          }
          curr = curr.parent;
        }
        if (faceNode) break;
      }

      let faceRotation: THREE.Quaternion | null = null;
      if (faceNode && faceNode.userData && Array.isArray(faceNode.userData.triqrRotation)) {
        faceRotation = new THREE.Quaternion(...faceNode.userData.triqrRotation);
      } else if (faceNode) {
        faceRotation = faceNode.quaternion.clone();
      } else {
        const hit = hits.find((h) => h.object.name && !h.object.name.includes("Body") && h.face);
        if (hit && hit.face) {
          const worldNormal = hit.face.normal.clone().transformDirection(hit.object.matrixWorld).normalize();
          const localNormal = worldNormal.clone().applyQuaternion(model.quaternion.clone().invert()).normalize();
          const up = new THREE.Vector3(0, 1, 0);
          let pUp = up.clone().addScaledVector(localNormal, -up.dot(localNormal)).normalize();
          if (pUp.lengthSq() < 0.001) pUp.set(0, 0, 1);
          const right = pUp.clone().cross(localNormal).normalize();
          const cUp = localNormal.clone().cross(right).normalize();
          faceRotation = new THREE.Quaternion().setFromRotationMatrix(
            new THREE.Matrix4().makeBasis(right, cUp, localNormal)
          );
        }
      }

      if (!faceRotation) return;

      const cameraPos = new THREE.Vector3();
      const modelPos = new THREE.Vector3();
      camera.getWorldPosition(cameraPos);
      model.getWorldPosition(modelPos);

      const faceNormalWorld = cameraPos.clone().sub(modelPos).normalize();
      const worldUp = new THREE.Vector3(0, 1, 0);
      let projectedUp = worldUp.clone().addScaledVector(faceNormalWorld, -worldUp.dot(faceNormalWorld));
      if (projectedUp.lengthSq() < 0.001) {
        projectedUp.set(0, 0, 1).addScaledVector(faceNormalWorld, -faceNormalWorld.z);
      }
      projectedUp.normalize();

      const right = projectedUp.clone().cross(faceNormalWorld).normalize();
      const correctedUp = faceNormalWorld.clone().cross(right).normalize();

      const faceMatrix = new THREE.Matrix4().makeBasis(right, correctedUp, faceNormalWorld);
      const desiredFaceWorld = new THREE.Quaternion().setFromRotationMatrix(faceMatrix);
      const desiredRootWorld = desiredFaceWorld.clone().multiply(faceRotation.clone().invert());

      if (model.parent) {
        const parentWorldRot = new THREE.Quaternion();
        model.parent.getWorldQuaternion(parentWorldRot);
        desiredRootWorld.premultiply(parentWorldRot.invert());
      }

      const startQuat = model.quaternion.clone();
      const targetQuat = desiredRootWorld;

      turning = true;
      controls.enabled = false;
      const startTime = performance.now();
      const duration = 600;

      const animateStep = (now: number) => {
        const elapsed = now - startTime;
        const progress = Math.min(1, elapsed / duration);
        const ease = 1 - Math.pow(1 - progress, 3);

        model?.quaternion.slerpQuaternions(startQuat, targetQuat, ease);

        if (progress < 1) {
          turnFrame = requestAnimationFrame(animateStep);
        } else {
          model?.quaternion.copy(targetQuat);
          turning = false;
          controls.enabled = true;
        }
      };

      cancelAnimationFrame(turnFrame);
      turnFrame = requestAnimationFrame(animateStep);
    };

    canvas.addEventListener("pointerdown", onPointerDown);
    canvas.addEventListener("pointermove", onPointerMove);
    canvas.addEventListener("click", onClick);

    function render() {
      animId = requestAnimationFrame(render);
      if (!turning) controls.update();
      renderer.render(scene, camera);
    }
    render();

    return () => {
      cancelAnimationFrame(animId);
      cancelAnimationFrame(turnFrame);
      resizeObserver.disconnect();
      canvas.removeEventListener("pointerdown", onPointerDown);
      canvas.removeEventListener("pointermove", onPointerMove);
      canvas.removeEventListener("click", onClick);
      controls.dispose();
      renderer.dispose();
      if (canvas.parentNode) {
        canvas.parentNode.removeChild(canvas);
      }
    };
  }, [src, background, onLoad, onError]);

  const heightValue = typeof height === "number" ? height + "px" : height;
  const widthValue = typeof width === "number" ? width + "px" : width;

  return (
    <div
      ref={containerRef}
      className={className}
      style={{
        position: "relative",
        width: widthValue,
        height: heightValue,
        minHeight: 280,
        backgroundColor: background,
        borderRadius: 12,
        overflow: "hidden",
        ...style,
      }}
    >
      {loading && (
        <div
          style={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            color: "#82776D",
            fontSize: 14,
            fontFamily: "system-ui, -apple-system, sans-serif",
            pointerEvents: "none",
          }}
        >
          Loading 3D model…
        </div>
      )}
      {errorMessage && (
        <div
          style={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            color: "#A33D32",
            fontSize: 14,
            fontFamily: "system-ui, -apple-system, sans-serif",
            pointerEvents: "none",
          }}
        >
          {errorMessage}
        </div>
      )}
    </div>
  );
}
