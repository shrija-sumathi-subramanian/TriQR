# TriQR Developer Integration Package

This package allows you to embed your 3D TriQR identity model directly into any website or application.

- **Model Name:** Hexagonal Prism Identity
- **3D Shape:** Hexagonal Prism
- **Asset File:** `assets/hexagonal-prism.glb`

---

## 1. Package Directory Structure

```
triqr-developer-package/
├── assets/
│   └── hexagonal-prism.glb       # Your exported 3D model (GLB format)
├── viewer/
│   └── index.html                # Standalone interactive viewer
├── html/
│   ├── triqr-embed.js            # Custom Web Component (<triqr-model>)
│   └── example.html              # Working HTML demonstration
├── react/
│   ├── TriQRModel.tsx            # React / Next.js client component
│   └── example.tsx               # Working React demonstration
└── README.md                     # Integration documentation
```

---

## 2. Hosting Your Model Asset

1. Copy `assets/hexagonal-prism.glb` to your website's public assets folder (e.g., `public/models/hexagonal-prism.glb`).
2. Ensure your web server serves `.glb` files with the MIME type `model/gltf-binary` and enables CORS if hosted on a separate CDN.

---

## 3. Integration Method 1: HTML / JavaScript (Custom Element)

### Step 1: Include the script and component

Copy `html/triqr-embed.js` into your site and reference it with `type="module"`:

```html
<!-- Include the Web Component -->
<script type="module" src="/scripts/triqr-embed.js"></script>

<!-- Render the 3D model -->
<triqr-model
  src="/models/hexagonal-prism.glb"
  height="520px"
  width="100%"
  background="#F5F0E9">
</triqr-model>
```

### Attributes Reference:
| Attribute | Type | Default | Description |
|---|---|---|---|
| `src` | `string` | **Required** | URL path to your `.glb` model file |
| `height` | `string` | `"480px"` | Container height (e.g. `"520px"` or `"80vh"`) |
| `width` | `string` | `"100%"` | Container width |
| `background` | `string` | `"#F5F0E9"` | Canvas background hex color |

---

## 4. Integration Method 2: React / Next.js

### Step 1: Copy the Component

Copy `react/TriQRModel.tsx` into your components directory (e.g. `components/TriQRModel.tsx`).

### Step 2: Install Three.js dependencies (if not already installed)

```bash
npm install three @types/three
```

### Step 3: Use the Component

```tsx
import TriQRModel from "@/components/TriQRModel";

export default function ProfilePage() {
  return (
    <main>
      <h1>My 3D Identity</h1>
      <TriQRModel
        src="/models/hexagonal-prism.glb"
        height={520}
        background="#F5F0E9"
      />
    </main>
  );
}
```

### Component Props:
| Prop | Type | Default | Description |
|---|---|---|---|
| `src` | `string` | **Required** | URL path to your `.glb` model file |
| `height` | `number | string` | `520` | Height in pixels or CSS string |
| `width` | `number | string` | `"100%"` | Width in pixels or CSS string |
| `background` | `string` | `"#F5F0E9"` | Canvas background color |
| `className` | `string` | `undefined` | Optional CSS class name |
| `style` | `React.CSSProperties` | `undefined` | Optional inline styles |
| `onLoad` | `() => void` | `undefined` | Callback fired when model finishes loading |
| `onError` | `(err: Error) => void` | `undefined` | Callback fired on loading error |

---

## 5. Built-in Interactions

Both the Web Component and React Component support:
- **Mouse / Touch Drag:** Rotate smoothly in any direction with damping.
- **Scroll Wheel / Pinch Zoom:** Zoom in and out with safe bounding limits.
- **Upright Click-to-Front:** Clicking any QR face smoothly aligns that face directly toward the camera, keeping the text and QR code right-side up for easy scanning.
- **Drag Thresholding:** Click-to-front does not trigger accidentally while dragging to rotate.
- **Responsive Layouts:** Uses `ResizeObserver` to adapt automatically to any screen size.
- **Automatic Resource Cleanup:** Disposes WebGL contexts, geometries, and textures when unmounted to avoid memory leaks.
